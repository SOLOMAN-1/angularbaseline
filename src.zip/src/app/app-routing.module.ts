import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PurchaseOrderListComponent } from './purchaseOrder-list/purchaseOrder-list.component';
import { PurchaseOrderDetailsComponent } from './purchaseOrder-details/purchaseOrder-details.component';
import { PurchaseOrderFormComponent } from './purchaseOrder-form/purchaseOrder-form.component';



const routes: Routes = [
  { path: 'purchaseOrder-list', component: PurchaseOrderListComponent },
  { path: 'purchaseOrder-details/:id', component: PurchaseOrderDetailsComponent },
  { path: 'purchaseOrder-form', component: PurchaseOrderFormComponent },
  { path: '', redirectTo: '/purchaseOrder-list', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
