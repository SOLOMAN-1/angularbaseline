import { Component, Input, OnInit } from '@angular/core';
import { PurchaseOrder } from '../models/PurchaseOrder';
import { Observable } from 'rxjs';
import { PurchaseOrderService } from '../services/purchaseOrder.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-purchaseOrder-details',
  templateUrl: './purchaseOrder-details.component.html',
  styleUrls: ['./purchaseOrder-details.component.scss']
})
export class PurchaseOrderDetailsComponent implements OnInit {
  purchaseOrder$!: Observable<PurchaseOrder>; 
  purchaseOrder!:PurchaseOrder;
  constructor(private purchaseOrderService: PurchaseOrderService,private route: ActivatedRoute){

  }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      //get parameter from id
      const id=params['id'];
      this.getEvent(id);
      console.log(id);
      
    });
   
  }
  getEvent(id: any) {
    this.purchaseOrder$=this.purchaseOrderService.getPurchaseOrder(id);
    this.purchaseOrder$.subscribe((data)=>{this.purchaseOrder=data;console.log(this.purchaseOrder)});
  //complete this function
  }
}
