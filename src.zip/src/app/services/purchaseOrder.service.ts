import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
// import { environment } from 'src/environments/environment';
import { PurchaseOrder } from '../models/PurchaseOrder';
@Injectable({
  providedIn: 'root'
})
export class PurchaseOrderService {

  // private apiUrl = environment.apiUrl; 

  constructor(private http:HttpClient) {}

  getPurchaseOrders(): Observable<any> {
    // complete this function
    return this.http.get('http://localhost:3000/purchaseOrders');
  }

  getPurchaseOrder(id: number): Observable<any> {
   // complete this function
   return this.http.get(`http://localhost:3000/purchaseOrders/${id}`);
  }

  addPurchaseOrder(purchaseOrder: PurchaseOrder): Observable<any> {
      console.log("iinsdie purchase order",purchaseOrder);
      // complete this function
      
      return this.http.post('http://localhost:3000/purchaseOrders',purchaseOrder);

  }
}
