import {ItemDetail} from "./ItemDetail";

export interface PurchaseOrder {
  id: number;
  departmentName: string;
  itemDetails: ItemDetail[];
  orderDate: string;
  status: string;
}