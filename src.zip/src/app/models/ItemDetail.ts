export interface ItemDetail {
    itemName: string;
    quantity: number;
}