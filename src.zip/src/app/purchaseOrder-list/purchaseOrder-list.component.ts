import { Component, OnInit } from '@angular/core';
import { Observable, filter, map, of } from 'rxjs';
import { PurchaseOrderService } from '../services/purchaseOrder.service';
import { PurchaseOrder } from '../models/PurchaseOrder';

@Component({
  selector: 'app-purchaseOrder-list',
  templateUrl: './purchaseOrder-list.component.html',
  styleUrls: ['./purchaseOrder-list.component.scss']
})
export class PurchaseOrderListComponent implements OnInit {
  filteredPurchaseOrders$: Observable<PurchaseOrder[]> = of([]);
  purchaseOrders$: Observable<PurchaseOrder[]> = of([]);
  purchase!:PurchaseOrder[];

  constructor(private purchaseService:PurchaseOrderService) { }

  ngOnInit(): void {
      // complete this function
      this.getPurchaseOrders();
  }

  getPurchaseOrders() {
    this.purchaseOrders$=this.purchaseService.getPurchaseOrders();
    this.purchaseOrders$.subscribe((data)=>this.purchase = data)
   // complete this function
  }

  searchPurchaseOrders(event: any) {
    const term=event.target.value;
    this.purchaseOrders$=of(this.purchase.filter((data)=> data.id===term));
     // complete this function
  }

}
