import { Component, EventEmitter, OnInit, Output } from "@angular/core";
import {
  AbstractControl, FormArray,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  Validators,
  FormControl
} from "@angular/forms";
import { PurchaseOrder } from "../models/PurchaseOrder";
import { PurchaseOrderService } from "../services/purchaseOrder.service";
import { Router } from "@angular/router";
import { Observable } from "rxjs";

@Component({
  selector: "app-purchaseOrder-form",
  templateUrl: "./purchaseOrder-form.component.html",
  styleUrls: ["./purchaseOrder-form.component.scss"],
})
export class PurchaseOrderFormComponent implements OnInit {
  purchaseOrderForm!: FormGroup;


  constructor(private fb: FormBuilder,private purchaseOrderService: PurchaseOrderService, private router:Router) {}

  ngOnInit(): void {
    // Initialize the form with validators
    this.purchaseOrderForm = this.fb.group({
      orderID:['',Validators.required],
      departmentName:['',Validators.required],
      orderDate:['',Validators.required],
      status:['',Validators.required],
      itemDetails:this.fb.array([
       
      ])

    })//init form here
  }

  get itemDetailsArray() :FormArray{
    return this.purchaseOrderForm.get('itemDetails') as FormArray;
    //complete this function
  }
  addItemDetail() {
    const itemDetail =  this.fb.group({
          itemName:['',Validators.required],
          quantity:['',Validators.required]
        })
    this.itemDetailsArray.push(itemDetail);
    
  }

  removeItemDetail(index: number) {
      //complete this function
      this.itemDetailsArray.removeAt(index);
  }
  // dateValidator(control: AbstractControl): ValidationErrors | null {
  //  //complete this function
  // }

  // Function to submit the form
  onSubmit() {
  
    if (this.purchaseOrderForm.valid) {
      try{
        this.purchaseOrderService.addPurchaseOrder(this.purchaseOrderForm.value).subscribe((data)=>console.log(data));
       
      }
      catch(err){
        console.error(err);
      }
      
      this.router.navigate(['/purchaseOrder-list'])

     //complete this function after success return to  purchaseOrder-list
  }
  }
  // Helper function to mark all controls in the form group as touched
  // markFormGroupTouched(formGroup: FormGroup) {
  //   Object.values(formGroup.controls).forEach((control) => {
  //     control.markAsTouched();

  //     if (control instanceof FormGroup) {
  //       this.markFormGroupTouched(control);
  //     }
  //   });
  // }
}
